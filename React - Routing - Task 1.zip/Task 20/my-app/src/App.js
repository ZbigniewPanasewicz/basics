import { Routes, Route } from 'react-router-dom';
import Header from './components/Heading';
import Landing from './components/Landing';
import Products from './components/Products';
import About from './components/About';
import './App.css';


export default function App() {
  return (
    <div className='App'>
      <Header />

      {/* Add other componets */}
      <Routes>
        <Route exact path="/" element={<Landing />} />
        <Route path="/products" element={<Products />} />
        <Route path="/about" element={<About />} />
      </Routes>
    </div>
  );
}
 