// About component
import React from 'react'
import { Link } from "react-router-dom";

export default function About() {
    return (
        <div>
            <h2>About</h2>
            <hr />
            <nav>
                <Link to="/">Home</Link>
                <Link to="/products">Products</Link>
            </nav>
            <hr />
            
        </div>
    );
}