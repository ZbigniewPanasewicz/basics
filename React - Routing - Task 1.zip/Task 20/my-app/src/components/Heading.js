// Header component
import React from 'react'

export default function Header() {
    return (
        <h1>Dirty Socks Shop</h1>
    );
}