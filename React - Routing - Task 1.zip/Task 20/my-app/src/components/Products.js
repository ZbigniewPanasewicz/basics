// Products component
import React from 'react'
import { Link } from "react-router-dom";

export default function Products() {
    return (
        <div>
            <h2>Products</h2>
            <hr />
            <nav>
                <Link to="/">Home</Link>
                <Link to="/about">About</Link>
            </nav>
            <hr />
            
        </div>
    );
}