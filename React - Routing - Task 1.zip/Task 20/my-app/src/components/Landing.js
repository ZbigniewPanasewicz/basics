import React, { useState } from 'react';
import { Link } from "react-router-dom";

export default function Landing() {
  const [username, setUsername] = useState('');
  const [isLoggedIn, setIsLoggedIn] = useState(false);

  const handleLogin = (event) => {
    event.preventDefault();
    if (username.trim()) {
      setIsLoggedIn(true);
      console.log('User logged in:', username);
    }
  };

  const handleLogout = () => {
    setIsLoggedIn(false);
    setUsername(''); // Clear the username
    console.log('User logged out');
  };

  return (
    <div>
      <h2>Welcome to our shop!</h2>
      <hr />
      <nav>
        <Link to="/products">Products</Link>
        <Link to="/about">About</Link>
      </nav>
      <hr />
      {isLoggedIn ? (
        <>
          <h1>Welcome, {username}!</h1>
          <button onClick={handleLogout}>Logout</button>
        </>
      ) : (
        <form onSubmit={handleLogin}>
          <input
            type="text"
            placeholder="Username"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            required
          />
          <button type="submit">Login</button>
        </form>
      )}
    </div>
  );
}
